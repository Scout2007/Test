# Project context: the LREF fleet battle

## What the project is

- A Blender 5.2 LTS recreation of LREF starships from JCB's web serial *Wearing Power Armor to a Magic School* (WPAtaMS), built from Sir_Lazz's official concept art. It is heading toward a roughly two-minute fleet-battle animation in the style of *The Expanse*.
- **The look:** photoreal, "a real spacecraft being filmed", in the style of the **SAVAGES** animated shorts on YouTube. That means harsh high-contrast light, reflective metal panels, MLI insulation blankets, cables and handrails, deep shadow, and a film grade with halation, crushed blacks and grain.
- **The user's words:** "Realistic please." "I want to use this to recreate a fleet combat scene similar to those from the expanse." The author describes the setting as "a soft sci fi setting wearing a hard sci fi coat".
- **Stated goal for the battle (2026-09-27):**
  - missiles and interception, EW, lasers, chaff, flares and smoke;
  - overheating, radiator deployment and damage;
  - Newtonian flip-and-burn motion, spinal-cannon turns;
  - backline capital ships, frontline drones, big missile volleys;
  - all per the author's ship descriptions;
  - against a defending force with stealth orbital missile and railgun emplacements, long-range ground weapons, and an asteroid belt.

## What is already built

The modelling session built these. You can't open the files; this section and `project_docs/` describe them.

### L.R.E.F.S. Endeavor: Ryland-class cruiser, about 1,194 m long in the model, fully rigged

Every animatable property is listed in `project_docs/README_blender_project.md`.

- **Hull:** octagonal. The art is a **top view**.
- **Rings:** twin hab rings run through hull tunnels. Spin gravity at 2.4 rpm = 1 g.
- **Shield and warp rings:** a gold impact shield at the bow launches forward before battle, on its own thrusters. Both warp rings stay on the ship.
- **Radiators:** 4, at 90° to each other. They telescope straight out of manifold housings, glow with heat, and retract in warp.
- **Railguns:** 6 **M-1C twin railcannon turrets**: 4 on the side faces, plus 2 "well batteries" that rise on 9 m lifts out of wells in the hull.
- **Lasers:** 8 laser focusing arrays, SAVAGES-style telescope barrels. The beams are invisible; only the lens glows UV-violet while firing. Plus 8 PD lasers.
- **Close defence:** 16 CIWS; point-defence cannons come straight out of the hull in a circle, low-profile.
- **Plasma:** 4 plasma lances.
- **Missiles:** 16 VLS cells (the dark 2×4 grids on the hull chamfers are missile tubes).
- **Countermeasures and EW:** launchers for chaff, flares and smoke; EW jammers.
- **Sensors and bow:** an antenna boom with RCS at the bow; sensor masts; RCS thrusters.

### M-1C twin railcannon: the fleet's standard heavy railgun turret, a separate reusable asset

- **Build:** two railcannons per turret, each made of two conducting rails with the slug between them, inside an armoured supershell that splits and lifts open. A **receiver** at the rear, bigger than the shell, takes the whole barrel on recoil.
- **Wake-up from stowed** (about 6–9 s in all):
  1. The capacitor-bank lids and rear radiator louvres open; amber charge cells and meters light; beacons flash.
  2. The travel-lock clamps release and the crutch folds flat.
  3. The cradle lays onto the target.
  4. The shell opens. This takes 3–6.5 s depending on the wake style; the user is choosing between split, ripple, bulk, extend and combined.
- **Each shot:**
  1. A 1.2 s charge: the gun shudders and throbs.
  2. A blue plasma pulse runs up the bore in 0.33 s.
  3. The slug leaves: a white flash, a blue plasma ball, a forward gas plume about 110 m long, a shock ring, bright jets fired back from the muzzle brake, and a long tracer.
  4. The barrel recoils 7 m into the receiver.
  5. The radiator fins burst out and glow orange, cooling over tens of seconds.
- **Colour rules:** blue appears only as the plasma pulse during a shot; heat glows only on the fins, and only on their radiator face.

### Not built yet (reference art only, in `reference_art/`)

| Ship | Class | Size | Notes |
|---|---|---|---|
| L.R.E.F.S. Astrid | Hanuman-class heavy cruiser | ~1,600–1,700 m | Spinal cannon along the full hull, 8 stacked radiator fins, AVPSA sensor dish about 100 m across |
| Garibaldi-Ivanova | Frigate | ~400–450 m | Modular: hedgehog missile pods, or gun or PD modules |
| Destroyer | ECW | ~200 m | Huge parabolic antenna, deployable satellites and drones |
| Corvettes | — | 50–150 m | — |
| The defending force | — | — | — |

## Render budget (measured on the user's machine: Cycles, OptiX GPU)

| Scene | Resolution | Samples | Time per frame |
|---|---|---|---|
| M-1C turret shot (one turret plus a hull patch) | 60% of 1920×804 | 64 | about 3–3.5 s |
| M-1C turret shot | 50% | 24, denoised | about 2.3 s |
| Endeavor hero close-up (the whole ship scene is far heavier; the .blend is 26 MB) | full | 128 | about 30–40 s, the draft's estimate |

The film is **2,880 frames**. At hero-shot cost that is roughly a day of rendering per full pass on one GPU. So a feasible storyboard:
- reuses set-ups;
- keeps the heaviest multi-ship shots short;
- uses distance and darkness honestly: wide space shots can be simpler;
- puts heavy FX (swarms, debris, nuclear flashes) where they count.

## Already decided (ask the user before changing any of it)

- **Weapon design:**
  - New weapon designs go through concept sheets, and the user picks, before anything is modelled.
  - All cannons are twin mounts. All six railgun mounts on the Endeavor are the same M-1C.
  - Lasers: invisible beams; the lens glows UV-violet while firing; quilted MLI telescope barrels.
  - Railcannon firing look: the "hard tracer" muzzle style with the forward gas plume.
- **Ship design:**
  - Radiators extend straight out of the hull, never on pivots, so the heat path is never broken.
  - Only the gold impact shield launches.
  - No random greebles: every detail has a purpose and is integrated into the hull.
  - Cargo containers are plain. The lore mentions painted state flags; the user chose plain.
- **Rendering:** the ship and all weapon shots render in **Cycles**.

## The existing storyboard draft (`storyboard_draft/index.html`)

**Operation Tidebreak**: 2:00, 29 shots, 4 acts.
- **Scenario:** an LREF expeditionary group led by the Astrid and the Endeavor drops out of warp at the edge of a defended system. It fights through a mined asteroid belt ("the Shoals") to break the orbital defence of the planet "Harrow". Harrow is held by the monitor "Bastion", with a mass driver and fighter base on the moon "Kest".
- **What the draft contains:** tactical maps, doctrine rules with IDs (LREF O1–O7 / D1–D7, Harrow HO1–HO6 / HD1–HD6), physics notes (heat, time of flight, laser diffraction, IR visibility), engagement envelopes, and production notes.
- The user said **"I like the basics of the storyboard"**. The faction and place names are placeholders.

**Known staleness:**
- The draft predates the M-1C railcannon: its "enclosed railgun houses" are now M-1C turrets.
- Its render plan says "EEVEE for wides", but the user wants Cycles.

## Pack index

| Path | What it is |
|---|---|
| `00_PROMPT.md` | The session prompt |
| `lore/WPAtaMS_LREF_lore_posts.md` | The author's lore posts, verbatim: LREF Starships Parts 1–3 and T-SEC |
| `storyboard_draft/DRAFT_READABLE.md` | The draft storyboard in plain Markdown: shots, rules, maps, envelopes, production notes |
| `storyboard_draft/index.html` | The same draft as a page with sketches, maps and render frames (`img/`) |
| `reference_art/` | Sir_Lazz concept art: cruisers, size chart, frigate hedgehog and stripped, destroyer, T-SEC emblem |
| `renders/` | Current Blender renders of the Endeavor and the M-1C, plus two short clips. `renders/README.md` says what each one shows |
| `project_docs/README_blender_project.md` | The Blender project README: every rig property on the ship and the railcannon asset |
| `project_docs/project_notes.md` | The modelling session's running notes: decisions and history |
| `user_messages/` | Every message the user typed in the build sessions, oldest first (`long_user_messages.md` holds just the long ones) |

**You only have this pack.** The Blender project itself lives with the modelling session. Whatever the storyboard needs that isn't built yet goes into `ASSET_REQUESTS.md`, and the user carries that list back to the modelling session.
