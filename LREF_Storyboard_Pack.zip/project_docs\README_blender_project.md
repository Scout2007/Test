# L.R.E.F.S. Endeavor — Blender build (v8: M-1C railcannons, telescoping radiators, plated hull, SAVAGES look)

Built from Sir_Lazz's concept art for JCB's *Wearing Power Armor to a Magic School* (WPATAMS).
Blender 5.2 LTS, real scale (1 unit = 1 m, ship ≈ 1,194 m long), cinematic 2.39:1 frame.

## Files

| Path | What it is |
|---|---|
| `LREF_Endeavor.blend` | Ship + orbital environment + cameras + missile asset |
| `LREF_Railcannon_M1C.blend` | **Fleet asset:** the M-1C twin railcannon turret, rigged, with its canned firing cycle, on a preview stage (see *M-1C railcannon asset* below) |
| `lref_kit/` | Python kit the scenes are generated from: `parts` (hull, shield, rings, radiators, engines), `railcannon` (the M-1C turret), `weapons` (lasers + shared weapon helpers), `arms` (PDCs, VLS, countermeasures, EW, plasma lances; the old gunhouse railguns, now unused), `plating` (armour plates), `dressing` (utility trenches, stencils), `systems`, `quilt` (MLI blanket geometry), `fx`, `materials`, `environment`, `endeavor` (assembly) |
| `build_endeavor.py` | Regenerates the ship .blend from scratch (overwrites it, ~55 s) |
| `build_railcannon.py` | Regenerates the M-1C asset .blend (~8 s) |
| `render_previews.py` | Stills from any camera, optional state preset (`--set combat`) |
| `render_shots.py` | Stills of `camera:frame` pairs from any file in one session (`-- "CAM_RC_Jaws:128,CAM_RC_Hero:277"`) |
| `render_anim.py` | Animation to H.264 MP4 with camera cuts at given frames (`-- "CAM_A:1,CAM_B:69" --out renders/x.mp4`) |
| `render_demo.py` | 8 s combat-readiness clip of the ship (keys are not saved into the .blend) |
| `renders/` | Output stills and clips |

## What's on the ship

- **One build pattern for every mount** (taken from the SAVAGES laser turret; `lref_kit/arms.py`). Each mount is built from the same parts, in this order:
  1. A segmented bearing ring with drive teeth.
  2. A turntable.
  3. A ribbed yoke plate with a gearbox housing and a **low** elevation joint.
  4. Cradle side plates with lightening holes, an axle, and a toothed elevation sector driven by a pinion motor.
  5. The working body, riding **high** above the joint. Gun bodies have bolted armour walls and a tufted MLI blanket nestled on top.
  6. MLI-sleeved barrel sections with clamp rings and snaps, bolted under-boxes with vents, louvred radiator blocks, MLI capsule tanks (capacitor banks, ammunition drums), plumbing, hatches and cable loops.

  The PDCs, missile cells, countermeasure launchers, EW jammers and plasma lances follow it. The railcannons are the M-1C turret (below), designed through concept sheets first.
- **Armour plating** (`lref_kit/plating.py`) is real geometry, not a texture. Plates are laid in regular courses between the bulkhead frames, each with chamfered edges, a gap and bolt rows along its real edges.
  - **Heavy belt:** plates 0.72 m thick along the side faces.
  - **Lighter courses:** plates on the chamfers and deck margins.
  - **Nose armour:** extra thickness on the nose.
  - **Groove:** along the window rows.
  - **Recesses:** every hull-mounted system sits in a recess where the plates stop around it.
- **Weapons** (per JCB's lore the Ryland class has *no spinal cannon*):
  - **Every cannon is a twin.** All six railgun mounts carry the same **M-1C** turret at one size: two railcannons, each two bulky conducting rails with the slug between them.
    - 4 on the side faces (the turrets drawn on the hull edges), each on a 22 m armour deck disc let into the plating, with a travel lock 53 m ahead that cradles the chisel jaws when stowed.
    - 2 in the dorsal and ventral wells, in front of the 8 missile cells (the cannon drawn there in the art). Each rides a lift column (`battery_raise` pushes it up 9 m, clear of the well to fire at any bearing); its travel lock stays on the well floor.
  - 8 **laser focusing arrays**, modelled directly on the SAVAGES reference turret.
    - **Joint and cradle:** the elevation joint sits **low** in a ribbed yoke plate with its gearbox housing. A cradle carries the optics body and barrel **high above the joint**. A toothed elevation sector, driven by a pinion motor on the far bracket, provides the elevation, and a louvred radiator block sits between cradle and body.
    - **Body:** wrapped in a tufted beta-cloth blanket with rolled edges, star creases and tie-down straps. All the quilting is real geometry.
    - **Rear module:** carries an MLI capsule tank, plumbing and a hinged service hatch.
    - **Barrel and lens:** a fat blanket sleeve with snaps, a clamp ring, a boresight camera and a cable run. It ends in a polished lens lip with a dark iris ring and a slightly convex lens. The lens glows magenta-violet only while firing; beams are invisible.
    - **Under the barrel:** a bolted beam-director box with a vent grille.
    - **Mounting:** yokes sit outboard on both sides of the ship.
  - 8 point-defence lasers: the same design at 50 % scale, all black (black MLI, dark metal), like the purple-lens turret in the reference.
  - 16 PDC / CIWS mounts. Each has an armoured receiver with a quilted top and an MLI ammunition drum. Its seven barrels spin inside a perforated cooling jacket, it has a fire-control pod and a flexible feed chute, and it sits in an armoured sponson collar. Elevation runs −10° to +60°.
  - 4 plasma lances (the nose slots in the art), 16 VLS missile cells with opening doors, 6 chaff/flare launchers, 2 EW jammers.
- **RCS, as drawn:**
  - White, red-tipped thruster pods on the nose sides and aft quarters.
  - Dark angular thruster blocks at the main-hull front corners.
  - Stern quads.
- **Sensors and comms:**
  - The long forward antenna boom along the top of the nose, with a forked hinge fitting and a tip pod with a red marker.
  - 6 phased-array radars, 2 star trackers and 4 IR search-and-track balls.
  - The high-gain dish, the sensor mast and the dish cluster.
- **Structure you can read** (no random greebles; every piece belongs to a system):
  - Bolted bulkhead frames that stop at the decks, wells, barbettes, ring-tunnel mouths, arrays and radiator slots.
  - Cable trays on stand-off brackets.
  - Reactor-to-radiator coolant lines and armoured edge chines.
  - MLI tanks.
  - Stern-shoulder thermal louvres.
- **Crew access:**
  - 8 airlocks with work lights, and grab-rail routes from each lock to the hardware it serves.
  - Service panels: capacitor/magazine hatches beside each railgun barbette, PDC reload panels, and coolant-pump access behind the radiator slots.
  - Docking ports, deck handrails, and floodlights on the name.
- **Moving structure:**
  - Counter-rotating hab rings.
  - Four radiator fins at 90° (port and starboard flat in the top view, the dorsal one the edge-on strip on the aft centreline, the ventral one mirrored). Each extends **straight out** of a manifold housing on the hull as telescoping bands; the root band never leaves the housing, so the coolant path is never broken. Slot doors close last.
  - The impact shield launches on its own, with separation thrusters on its backplate firing between the front ring's spokes. **Both warp rings stay on the ship**: together they generate the warp bubble, and both have emitters that glow with `warp_charge`.
  - Five engines with long plumes.

## Animation controls

Select the empty **`LREF_Endeavor`** → Object Properties → Custom Properties, and keyframe any value.

| Property | Effect |
|---|---|
| `engine_throttle` | Main-drive plumes: length and brightness (0 = off) |
| `rcs_bow`, `rcs_stern` | Fire the bow or stern RCS thrusters |
| `shield_separation`, `shield_thrusters` | Launch the impact shield forward (metres) with its thrusters; the release latches on the ring hub open automatically |
| `warp_charge` | Emitter glow on the front and aft warp rings (spool-up / drop-out) |
| `radiator_deploy` | 1 = fins out; about 0.12 = fins stowed; 0 = slot doors closed |
| `heat`, `radiator_glow` | Thermal load: dull red at 0.3, white-hot past 2.5 |
| `rail_traverse`, `rail_elevation` | The four side railcannons. Elevation −0.026 = stowed on the travel locks, up to 0.52 (30°) |
| `battery_raise`, `battery_traverse`, `battery_elevation` | The two well batteries: lift 0 = on the well floor, 1 = raised 9 m clear to fire; elevation as above |
| `rail_wake` | All railcannons power up: the capacitor-bank lids and rear radiator louvres open, the charge cells and meters light, the beacons flash. Key it over ~2 s |
| `rail_lock` | All six travel locks: 1 = up, clamps shut on the jaws; 1–0.8 the clamps swing off, 0.8–0 the crutch falls flat. Fold before laying or raising |
| `rail_arm` | All railcannons open their supershells. Key it linearly over `railcannon.arm_time()` seconds (3.2 s for the ship's style): the latches drop, the receiver hoods lead, the halves crack, rise and clunk, the jaws open |
| `rail_scales` | Ship-wide radiator fins for every gun: 0 = flush in the shell, 1 = burst out. Per gun, use the mount's `fins_a` / `fins_b`; the larger value wins. Key it over ~4 frames with BACK easing as that gun's first slug leaves. The lower fins wait until the gun is laid ~12° up (interlock) |
| `rail_heat` | Ship-wide fin heat, the only heat glow on the guns: dull red at 0.3, bright orange at 1. Per gun: the mount's `heat_a` / `heat_b` |
| `rail_magazine` | Drum magazine index (1 = one slug, 45°) |

Each mount empty (`Railgun_1`–`4`, `Battery_Dorsal`, `Battery_Ventral`) also has:

- its own `traverse` and `elevation`, added to the ship values;
- a **shot clock** per gun, `shot_a` and `shot_b` (see *Firing* below), and a **charge** per gun, `charge_a` / `charge_b` (0 → 1 over ~1.2 s up to the trigger, back to 0 just after the slug leaves);
- per-gun `fins_a` / `fins_b` and `heat_a` / `heat_b`, so only the gun that fired vents.
| `laser_traverse`, `laser_elevation`, `laser_power` | All laser arrays; `laser_power` is the lens glow. Elevation runs −10° to +40° (each `Laser_*` / `PDLaser_*` empty has its own `traverse`, `elevation`) |
| `ciws_traverse`, `ciws_elevation`, `ciws_rpm` | CIWS turrets (per-turret props on each `CIWS_NN`) |
| `vls_open` | Missile cell doors |
| `lance_power`, `reactor_glow`, `engine_glow` | Glows: plasma lances, reactor slot, nozzle idle heat |
| `ring_rpm` | Hab ring spin (2.4 rpm = 1 g) |

- **Firing:** each shot is one clock. Key `shot_a` = 0 on the trigger frame and 2.0 two seconds later (linear), hold it, and drop it back to 0 on the next trigger.
  - **0–0.33 s:** the plasma armature runs up the bore from the breech to the muzzle as a blue-white pulse, and the collector rings flash as it passes. This is the only time the bore glows.
  - **At 0.33 s the slug leaves:** the muzzle blast plays in the turret's style, the muzzle-brake ports jet out and back toward the breech, and the gun recoils.
  - **By 2 s:** everything has faded.
- **Blast styles:** `railcannon.FX_STYLES`, chosen with `build_turret(..., fx=...)`:
  - `tracer` (V4, the standard):
    - a hard white-hot flash, then a churning jet of muzzle gas pushed out ahead of the gun, about 110 m long, white-hot at the muzzle and dissolving forward as blue plasma;
    - a light travels with the gas, so on the night side the gas lights up the ship;
    - a flat shock disc and a long bright tracer;
    - bright plasma jets fired back toward the breech from the outboard brake ports.
  - `plasma` (V1): plasma bloom.
  - `blast` (V2): naval-gun fireball with smoke.
  - `sparks` (V3): burning-metal spark storm.
  - `build_fx_variants.py -- [--style <name>] [--wake <style>] [--dark 1] [--short 1]` renders a firing clip in Cycles (like the ship): the turret wakes up from stowed, arms, charges and the near gun fires, seen from about 340 m and then close up (`--short 1`: the wake-up, then one close shot). `--stills 50,90 [--cam CAM_FX_Rear]` renders stills instead. `assemble_clips.py` joins clips with titles.
- **Rendering the asset:** the file is saved set to Cycles. Keep `transparent_max_bounces` high (it is 64), or stacked plasma layers render black.

## M-1C railcannon asset (fleet standard)

`LREF_Railcannon_M1C.blend` holds the turret every LREF ship uses, as a marked **collection asset** `RC_M1C` (tags: LREF, weapon, railgun, turret, rigged). It shares one set of meshes and glow materials across any number of copies. It was chosen through the concept sheets (round 5, M-1C): the RG-3 open-cradle backend and the M-1 split-and-lift supershell, with the crest scales as radiators.

- **Mechanism, front to back:**
  - **Chisel-tip jaws:** hinged on their outer edges and pushed open by rams inside the shell. Their cavities and lips are tiled. In the two-stage wake styles a tip petal on each jaw folds back once the jaw is open.
  - **Muzzle:** a stepped crown, a muzzle brake with three vent ports each side, and a lip around the open bore. The rail faces show inside the bore.
  - **Rail pack:** two dark tungsten-copper rails with a ceramic insulator band between them, and a collector ring at every link station. A plasma slot glows only while a shot runs.
  - **Shell:** each half rises on parallel links that fold flat into the side seams, 3.2 m up and 1.75 m forward. The motion is staged and heavy: seam latches drop, each piece cracks open, pauses, rises and clunks against its stops, then the jaw locks jolt and the jaws (48°) swing open and thunk. The last 8 m of each half is a bare **plug** (behind the seal band) that always sits inside the receiver.
  - **Wake styles** (`railcannon.WAKE_STYLES`, chosen with `build_turret(..., wake=...)`; the ship uses `split`):
    - `split`: each half rises in one piece.
    - `ripple`: each half is four overlapping segments that rise one after another from the breech to the muzzle.
    - `bulk`: overlapping flank plates slide down and out in a wave into heavy side armour; butterfly vent doors open on the receiver.
    - `extend`: stowed, the barrel is telescoped 24 m shorter (three sections, each slimmer than the one behind it); the sections run out and lock, then the shell opens. The travel lock sits 24 m further aft.
    - `combined`: extend, ripple and bulk together, with the tip petals.
  - **Receiver:** split armoured hoods, wider and taller than the shell, between the shell and the breech housing. They rise on lift rams just ahead of the halves, so on each shot the whole lifted shell slides 7 m straight inside. It holds, then runs out again over about 1.5 s; the cradle jumps about 0.9° and settles.
  - **Charge:** for the 1.2 s before each shot the barrel draws back and buzzes, the shell pieces throb outward, the jaws flex, flush fins crack open and chatter, the cradle trembles and the meters flicker.
  - **Radiator fins:** lie flush in a channel along each crest, hinged on their forward edges. They burst out and lean back toward the breech. Only the radiator face and its edges glow (the armour face stays white and catches the glow of the fin ahead); each fin row throws orange light over the shell, the twin barrel and the deck. Each hinge is a coolant manifold.
  - **Breech housings and capacitor-bank counterweights:** pulled down into the gun pit by twin elevation rams. On power-up (`wake`) each bank's clamshell lids open on rows of charge cells that light amber as the bank fills, and its rear radiator louvres open in a ripple.
  - **Trunnion pylons:** heavy raked structures leaning in on the trunnion bearings, with raking struts front and rear, an outboard buttress, ribs and bolted armour. Their conduits dive into the turntable through glands. Drum magazines sit on the trunnion axis, so the feed runs through the hollow trunnions.
  - **Mounting:** the turntable sits down inside an armoured barbette drum (a dark well gap round it), buttress ribs bolt the drum to the deck, and pipe bundles dive through deck glands into the hull. The travel lock stands on a bolted foundation plinth; its clamps grip the stowed lower jaws.
- **Controls:** custom properties on the `RC_M1C` empty: `traverse`, `elevation`, `wake`, `arm`, `charge_a`, `charge_b`, `shot_a`, `shot_b` (shot clocks, see *Firing*), `fins_a`, `fins_b`, `heat_a`, `heat_b` (each gun vents on its own), `lock`, `magazine`. They are all simple-expression drivers (the shudders use the driver `frame`), so no *Auto Run Scripts* is needed. They are flagged library-overridable.
- **`RC_FireCycle`:** a ~17 s action (fake user) that runs the whole cycle: power up, unclamp, lay, arm, charge and fire A (the fins burst out), fire B, reload, salvo, cool, close, stow and power down. `railcannon.keyframe_cycle(ctl, wake=...)` keys it for any wake style. It plays in the asset file. On a copy, clear it or offset it in the NLA.
- **Using it in another ship file:** Asset Browser › drag `RC_M1C` in.
  - **Append:** a local copy you animate directly.
  - **Link:** use Object › Library Override › Make on the `RC_M1C` empty so each mount animates on its own.
  - **Smaller hulls:** scale the empty down.
  - **In the kit:** call `railcannon.build_turret(col, parent, M, name, matrix)`. This is how the Endeavor builds its six.
- **Preview stage:** the `Stage` collection (plated hull patch, cameras) is not part of the asset. The `CAM_RC_Jaws`, `CAM_RC_Window`, `CAM_RC_Crest`, `CAM_RC_CrestAft`, `CAM_RC_Burst`, `CAM_RC_Frame` and `CAM_RC_Pit` cameras ride on the gun, so they keep framing it through the cycle.
- **Spin:** the rings and CIWS barrels spin with the frame number, so changing their rpm mid-shot jumps rather than easing.

## Look (the SAVAGES reference)

- **Hull metal:** satin metal. Every plate is partly metallic, with broad soft roughness stains.
  - The octagon faces are shaded as if they curved round the ship's axis, so light rolls from white into black across each face while the silhouette stays octagonal.
  - A few canted, bare-metal plates flash differently in the sun.
  - Plate contrast, rivets and fine seams fade with camera distance, so the hull reads clean white from afar (as drawn) and never shimmers.
- **Grade** (compositor `LREF_Compositor`):
  - **Glow:** a tight bloom plus a wide soft halation round the whites.
  - **Tone:** a black-level crush so shadow falls into true black, and muted colour with a slightly cool shadow lift. Glows are exempt: pixels lit by the emission pass skip the muted-colour step, because AgX turns even slightly desaturated pure hues pastel. Hot fins, plasma, lenses and marker lights keep their colour.
  - **Lens and film:** slight lens dispersion, a heavy vignette, and animated film grain (white noise re-seeded per frame).
  - **Colour management:** AgX with the High Contrast look at exposure −0.3, and one hard key sun at 6 W/m².
- **Close-up materials:** beta cloth (with fabric creases), MLI foils, ceramic tiles, carbon composite, bare and dark metal, and cable jackets.

## Environment

- **Planet:** it lives in the **World shader**. The ship sits in low orbit above a procedural Earth-like planet with oceans, sun glint, clouds, an atmospheric limb and city lights. It lights the ship's underside in both Cycles and EEVEE.
  - To move or resize it, edit the `PlanetCenter`, `PlanetRadius` and `PlanetRotation` nodes in the World.
  - The sun direction is `TO_SUN` in `lref_kit/environment.py` (rebuild after changing it). The sun comes from ahead, to port and above, so the port-side cameras see the lit side.
- **Cameras:**
  - **Look-dev close-ups:**
    - Lasers: `CAM_LookDev_Yoke`, `CAM_LookDev_Front`, `CAM_LookDev_Pair` (black point-defence laser in front of a white main laser) and `CAM_LookDev_PD`.
    - Other mounts and plating: `CAM_LookDev_Railgun`, `CAM_LookDev_PDC` and `CAM_LookDev_Deck`.
    - Render them with `laser_power=1` and `laser_traverse` of about −0.3 to −0.45, for example: `render_previews.py -- lookyoke --engine CYCLES --samples 128 --pct 100 --set laser_power=1,laser_traverse=-0.45,laser_elevation=0.1`.
  - `CAM_Railgun_House` (port railcannons), `CAM_Laser_Close`, `CAM_Laser_Rear`, `CAM_Battery` (well battery), `CAM_Nose` (antenna boom and bow RCS).
  - `CAM_Close_Deck`, `CAM_Railgun_Close`, `CAM_Superstructure`, `CAM_Radiator_Slot`, `CAM_Orbit_Wide`, `CAM_Engines_Burn`, `CAM_Hero` and more.
- **Rendering:**
  - Cycles with GPU (enable OptiX in Edit › Preferences › System): about 30 s per 1920×804 frame at 128 samples.
  - EEVEE: a few seconds per frame for previews.

## Missiles and fleets

- **Missile asset:** in the excluded `LREF_Assets` collection (about 26 m long, with a plume and a `thrust` property). Use Add › Collection Instance › LREF_Assets, or link it from another file.
- **Fleet shots:** in your battle file, use File › Link › `LREF_Endeavor.blend` › Collection › `LREF_Endeavor`.
  - Background ships can be plain collection instances.
  - For a ship you need to animate on its own, use Object › Library Override › Make.

## Rebuilding

```
blender --background --factory-startup --python build_railcannon.py
blender --background --factory-startup --python build_endeavor.py
```

The two are independent: the ship builds its turrets from `lref_kit/railcannon.py` directly, and the asset file is for dropping the same turret into other files.

## Interpretation choices (not shown in the top-view art)

- **Hull:** the art is the top view, and the hull is an octagon. Hull height and hab-ring thickness were chosen so the ring tunnels pass through the side faces.
- **Recessed panel on the green band:** a weapons well. It holds the twin battery (the drawn cannon) and the 2 × 4 missile cells. It is mirrored on the ventral side.
- **Small drawn parts:** the white red-tipped nubs are RCS pods and the dark corner shapes are thruster blocks. The rod along the nose is an antenna boom. The dark 2 × 4 grids on the forward chamfers are missile tubes.
- **Front assembly:** the front white bar is a warp ring. It stays on the truss framing; only the gold impact shield is jettisoned.
- **Other hardware:** railguns, lasers, CIWS, radars, RCS, hatches and frames are placed to leave the ring tunnels and radiator slots clear.
