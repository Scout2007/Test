# Renders: what each file shows

These are current Blender renders from the modelling session, in the SAVAGES-style grade. The Endeavor's M-1C railcannon turrets appear in the "s1combat" and "m1c" sets.

## L.R.E.F.S. Endeavor

| File | Shows |
|---|---|
| `hero_s1combat.png` | Hero view of the Endeavor in combat configuration (railcannons armed) |
| `hero_m1c_stow.png` | The same hero view with the railcannons stowed on their travel locks |
| `battery_s1combat.png` | Close-up of a well battery: an M-1C raised on its 9 m lift out of its hull well |
| `house_s1combat.png` | Close-up of a side-face railcannon mount |
| `lookrail_s1combat.png` | Look-dev camera along the railcannon mounts |
| `lookaft_s1combat.png` | Look-dev camera toward the aft hull |
| `top_over_art_m1c.png` | Top view of the model overlaid on Sir_Lazz's concept art: a fidelity check (the art is a top view) |
| `orbit_v8d.png` | The ship in orbit over the planet |
| `looktrench_v8d.png` | Close-up of a hull utility trench (cables, framework) |
| `lookvls_v8d.png` | Close-up of VLS missile cells on the hull chamfer |
| `lookmast_v8d.png` | Close-up of a sensor mast |
| `endeavor_combat_demo.mp4` | Short motion test: shield launch and combat configuration (an early version, before the M-1C) |

## M-1C twin railcannon (asset renders on a test hull patch)

| File | Shows |
|---|---|
| `RC_FX_tracer_fins1_f300.png` | Day: after firing, the radiator fins are out and their radiator faces glow |
| `RC_FX_tracer_fins1dark_f300.png` | Night: the same moment; the fins light the shell and deck |
| `RC_FX_tracer_rec1_f244.png` | Firing, breech view: the whole lifted shell has recoiled 7 m into the receiver |
| `RC_FX_tracer_v10dark_f340.png` | Night, a third of a second after a shot: the plasma ball, shock ring, forward gas plume, back-jets and tracer. The fins here glow on both faces, an older look the user has since replaced with radiator-face-only |
| `RC_FX_tracer_ripple_t1_f236.png` | Armed in the "ripple" wake style: the overlapping shell segments are up, the jaws open, the tip petals folded back |
| `RC_FX_tracer_back1_f070.png` | Rear view after power-up: the capacitor-bank lids open on glowing charge cells, the radiator louvres open, the barbette set into the deck |
| `RC_M1C_Heavy_Cycles.mp4` | The near gun arming and firing, day then night: heavy staged motion, the 7 m recoil, the fins bursting out (an earlier version, before the receiver and the new wake-up) |
