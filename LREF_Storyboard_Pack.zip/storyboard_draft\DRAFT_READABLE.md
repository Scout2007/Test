# Draft storyboard "Operation Tidebreak": readable export

This is the same content as `index.html` in this folder, which also has sketches, maps and render frames if you can open it in a browser. Its data lives in the JavaScript near the bottom of the file. The draft was written before the M-1C railcannon was designed (see `../01_PROJECT_CONTEXT.md`).

## Premise

A two-minute fleet engagement in the style of *The Expanse*. An LREF expeditionary task group, led by L.R.E.F.S. Astrid and L.R.E.F.S. Endeavor, drops out of warp at the edge of a defended system. It fights its way through a mined asteroid belt to break the orbital defence of the planet Harrow.

- **Format:** 2:00, 2,880 frames at 24 fps, 29 shots, 2.39:1 at 1920×804, 4 acts.
- **Placeholders:** the operation, the defending faction and its places (Harrow, the moon Kest, the Shoals belt, the monitor *Bastion*) can all be renamed. Ship classes, weapon families and roles follow JCB's GUN classification posts. Ranges and speeds are working numbers for this production, not canon.

## Forces

**LREF Expeditionary Response Element (attacker).** It has warped in from outside the system and must decelerate, so it arrives with momentum it cannot hide and has to spend.
- **Backline:** L.R.E.F.S. Astrid, Hanuman-class heavy cruiser. Its spinal cannon runs the full hull length and its 100 m AVPSA sensor dish builds the fleet's picture. It runs hot, with eight stacked radiator fins.
- **Line:** L.R.E.F.S. Endeavor, Ryland-class cruiser and generalist, with no spinal cannon. The draft lists 6 twin railgun batteries, 8 laser focusing arrays, 8 PD lasers, 16 CIWS, 4 plasma lances and 16 VLS cells. The railgun batteries are now M-1C turrets.
- **Frigates:** one hedgehog missile frigate with its racks full; one gun frigate with railgun and laser batteries.
- **Destroyers:** two EW ships. They put up the local network screen and deploy jamming drones.
- **Corvettes:** four, as the anti-drone and anti-fighter screen.
- **Drones:** picket, decoy and point-defence drones from the cruisers.

**Harrow system defence (defender).** It owns the ground, knows every lane through the belt, and does not have to move to fight.
- **Anchor:** *Bastion*, a system-defence monitor: armoured, no warp drive, a battleship-grade reactor, heavy railgun turrets and a dense PD umbrella. It holds high orbit over Harrow.
- **Squadron:** three coilgun and missile frigates, plus six picket corvettes.
- **Strike craft:** fighter and drone swarms from a hardened base on the moon Kest.
- **Emplacements:** stealthed missile pods, three railgun platforms and proximity mines in the belt, plus more railgun emplacements along Bastion's orbit.
- **Ground:** a mass-driver battery on airless Kest. Laser arrays on Harrow, used to dazzle sensors because the atmosphere blunts them for killing.
- **EW:** jamming stations, and thermal and radar decoys that mimic frigates.

**The ground they fight over**
- **Warp exit:** outside the Shoals debris line. The group arrives at about 180 km/s closing speed and has to flip and burn, so its path is predictable for minutes. That is the defender's opening.
- **The Shoals:** a dense belt ring between the exit point and Harrow. It gives cover both ways and hides the stealthed pods, railgun platforms and mines.
- **Kest:** an airless moon with the mass driver and the fighter base. Its shadow hides launches.
- **Harrow:** the target world. Bastion and the orbital emplacements hold its high orbit, and its night side makes the final silhouette.

## Acts

| Act | Title | Time (s) | Summary |
|---|---|---|---|
| I | Drop-out | 0–24 | The group arrives with momentum it must kill. Flip, burn, jettison shields and go dark. |
| II | Long reach | 24–52 | Missiles across tens of thousands of km. The belt ambush springs, the first ship dies, and the Astrid answers. |
| III | The Shoals | 52–94 | Through the rocks at knife range: swarms, mass-driver fire, blinding, heat, a broadside and the lance. |
| IV | Hammer and anvil | 94–120 | A staged combined offensive against Bastion. Blind it, saturate it, then the spinal shot and the Casaba spear. |

**Timeline beats (s):** 0 warp exit · 13 flip & burn · 18 shields away · 28 hedgehog volley · 33 belt ambush · 46 destroyer lost · 49 spinal answer · 52 into the Shoals · 65 mass driver · 69 blinded · 73 radiators out · 77 fin hit · 81 broadside · 90 lance · 98 combined strike · 106 spinal hit · 110 Casaba · 117 hold.

## Shot list

Times are in seconds and frames at 24 fps, starting at frame 1. Rig keys name custom properties on the `LREF_Endeavor` empty; see `../project_docs/README_blender_project.md`. Time is compressed in the edit: a real long-range exchange takes minutes. "Render" means the draft used a frame from the Blender model (`img/`); the other shots have sketches only.

| # | Time (s) | Frames | Title | Camera | Action | Rig keys | VFX | Sound | Doctrine | Render |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0–5 | 1–120 | Black, then a star | EWS, 35 mm, locked off | Starfield. A point of light swells into a blue-white bloom as the warp bubble collapses. The Endeavor resolves out of it, shield forward, both warp rings glowing. | warp_charge 1→0.3 | Warp-exit flash (comp) | Silence, then a sub-bass drop | O1 | |
| 2 | 5–9 | 121–216 | Rings cool | CU, 50 mm, slow push | The front warp ring's emitters fade from blue to dark. A burst of bow RCS trims the drift. | warp_charge 0.3→0; rcs_bow pulse | Ring emitter glow, RCS puffs | Ticking metal, RCS thumps | O1 | img/bow_v4b_combat.jpg |
| 3 | 9–13 | 217–312 | The group arrives | EWS, 85 mm, long lens | Staggered warp flashes as the Astrid, two frigates, two destroyers and four corvettes drop in behind. Harrow and Kest lie ahead; the Shoals are a glittering band. | none | 7 warp flashes, belt glitter | Distant thuds, one per exit | O1 | |
| 4 | 13–18 | 313–432 | Flip and burn | WS, 28 mm, 90° orbit | The Endeavor pitches 180° on RCS and its main drive lights. A 900 m plume now points at the planet it is braking toward, and the whole group mirrors the move. | rcs_bow / rcs_stern pulses; engine_throttle 0→1; heat 1→1.6 | Main plume, RCS | Drive roar through the hull | O1, D3 | |
| 5 | 18–24 | 433–576 | Shield away | MS, 35 mm, from behind the shield | Separation thrusters fire between the front ring's spokes. The gold impact shield drifts free and tumbles away; both warp rings stay on the ship. Destroyers pop EW drones and the group goes radio-silent. | shield_thrusters 1; shield_separation 0→400 | Shield tumble, thruster plumes | Clamp bangs, then quiet | O1, O2 | img/endeavor_combat_demo_f060.jpg |
| 6 | 24–28 | 577–672 | The Astrid looks | MS + HUD insert, 50 mm | The Astrid's AVPSA dish slews. On the plot, tracks bloom: Bastion in high orbit, three frigates, the Kest base, forty unknowns in the belt. | none | HUD overlay (comp) | Soft sensor pings | O2 | |
| 7 | 28–33 | 673–792 | Hedgehog | WS, 24 mm, handheld shake | The hedgehog frigate ripple-fires sixty missiles in three seconds. The plumes curve into a formation and race away. | none | 60 missile instances, plumes | Staccato launch cracks | O3 | |
| 8 | 33–37 | 793–888 | The belt wakes | WS, 40 mm, drifting past rocks | Between the rocks, cold dark pods open like flowers. Missiles tumble out unlit and fire their motors only two kilometres clear, leaving no warm launch signature to track. | none | Pod doors, late motor ignition | Nothing, then hiss | HO2 | |
| 9 | 37–42 | 889–1008 | Countermeasures | MS, 35 mm, along the flank | Chaff and flare cartridges bloom and a smoke screen unfurls. CIWS barrels spin up and tracers stitch the dark. The main lasers track, lenses glowing violet, beams invisible, and incoming missiles pop one by one. | ciws_rpm 0→2400; ciws_traverse; laser_power 0→1; laser_traverse | Tracers, chaff sparkle, smoke, intercept flashes | PDC brrrt, flare pops | D1 | img/lookpair_final.jpg |
| 10 | 42–46 | 1009–1104 | Railguns in the rocks | WS, 50 mm | Three stealthed railgun platforms unmask in the belt. Muzzle flashes, and three slugs streak toward the line, visible only as glints. | none | Muzzle flashes, slug glints | Sharp cracks | HO1, HO2 | |
| 11 | 46–49 | 1105–1176 | First loss | MS, 40 mm | The destroyer *Wren* (a placeholder name), locked in its braking burn, is holed stern to bow. It vents atmosphere, its reactor scrams in a flash, and it breaks in two. | none | Entry flash, venting, hull break, debris | Muffled impact; the comms channel dies | HO1 | |
| 12 | 49–52 | 1177–1248 | Answer | EWS, 135 mm | The Astrid's spinal cannon fires down its kilometre-long barrel in a blue-white muzzle bloom. After a cut, a railgun platform erupts. | none | Muzzle bloom, impact eruption | A deep punch, then a delayed boom | O4 | |
| 13 | 52–57 | 1249–1368 | Into the Shoals | WS, 24 mm, tracking | The Endeavor threads between tumbling asteroids two to five kilometres across. Its radiators are stowed and it runs on heat sinks as rocks slide past the lens. | radiator_deploy 1→0.12; heat 1.6→1.9 | Rock parallax, dust glints | Low drone, creaks | D3, D5 | |
| 14 | 57–61 | 1369–1464 | Screens out | WS, 28 mm | LREF drones fan out ahead. From Kest's shadow a swarm of Harrow fighters and drones pours toward them. | none | Drone swarms (particle instancing) | Rising swarm whine | O7, HO4 | |
| 15 | 61–65 | 1465–1560 | Knife in the dark | MS, 40 mm | Corvettes and the black PD lasers cut through the swarm, violet lenses, invisible beams. Drones flash and die; one corvette takes a ramming drone and spins away burning. | laser_power 1 | Small intercept flashes, burning corvette | Pops, a scream of metal | D6 | img/lookpd_final.jpg |
| 16 | 65–69 | 1561–1656 | The moon speaks | EWS, 85 mm | A line of light leaves Kest's surface: the mass driver. A 50-tonne slug hits an asteroid three kilometres from the Endeavor and the rock bursts into a debris cloud. | none | Launch flash on Kest, rock burst, debris | Silence, then a pressure-wave rumble | HO3 | |
| 17 | 69–73 | 1657–1752 | Blind | CU sensor mast + POV insert, 85 mm | Harrow's planetary laser array dazzles the sensor window and it floods violet-white. The tactical display tears with EW noise. | none | Dazzle bloom and lens flare (comp), glitch overlay | Static howl | HO5 | |
| 18 | 73–77 | 1753–1848 | Too hot | MS, 35 mm | Heat alarms. The slot doors slide open and the radiator fins telescope out glowing orange, making the Endeavor a beacon. | radiator_deploy 0.12→1; heat 1.9→2.4 | Fin glow ramps | Alarm tones | D3 | |
| 19 | 77–81 | 1849–1944 | Fin hit | CU, 50 mm | A Harrow frigate's slug clips a radiator fin. It shatters into glowing shards, coolant flashes to vapour, and the remaining fins go white-hot. | heat 2.4→3.2 | Fin shatter (cell fracture), coolant vapour | Metal shear, hiss | HO1, D7 | |
| 20 | 81–86 | 1945–2064 | Broadside | WS → CU, 24 mm → 50 mm | The Endeavor rolls to present its port side. The twin railgun turrets traverse and elevate while the well batteries rise from their wells, and the full broadside fires with recoil and bore glow. | rail_traverse; rail_elevation; rail arming and firing keys; battery_raise 0→1 | Muzzle flashes, slug streaks | Hammering cracks | O6 | img/house_final.jpg |
| 21 | 86–90 | 2065–2160 | Breach | WS, 40 mm | Harrow frigate one takes four slugs and breaks apart. Frigate two throws thermal decoys and runs for Kest. | none | Break-up, decoy flares | Groaning metal | HD2, HD4 | |
| 22 | 90–94 | 2161–2256 | Lance | CU nose, 28 mm | The plasma lance channels on the nose glow. At 40 km the Endeavor stabs the fleeing frigate with a magnetically bottled plasma jet. | lance_power 0→1 | Lance core glow, plasma jet | Rising electric whine, a crack | O6 | |
| 23 | 94–98 | 2257–2352 | The anvil | EWS, 50 mm | Out of the belt. Bastion swings its turrets over Harrow's limb, and orbital railgun emplacements unmask along its orbit. | none | Turret motion, emplacement lights | Low brass sting | HO6, HD1 | |
| 24 | 98–102 | 2353–2448 | Blind it | MS, 35 mm | The destroyers and the Endeavor's arrays dazzle Bastion's sensors and EW floods its fire-control net. The hedgehog's second wave, carrying Casaba-howitzer warheads, fans out on staggered burns timed to arrive together. | laser_power 1 | Missile fan, EW shimmer | Rising score | O5, O3 | |
| 25 | 102–106 | 2449–2544 | Wall of fire | WS, 40 mm | Bastion's PD wall of tracers and lasers kills missile after missile. The sky fills with small flashes as decoys burst. | none | Tracer streams, intercept flashes | Dense crackle | HD5 | |
| 26 | 106–110 | 2545–2640 | Spinal | EWS, 200 mm | Aligned during the flip, the Astrid fires its spinal cannon while Bastion's point defence is saturated. The slug hits amidships in a spray of armour spall and a shock ring. | none | Impact flash, spall cone, shock ring | Everything drops out, then a single deep boom | O4, O7 | |
| 27 | 110–114 | 2641–2736 | Casaba | WS, 35 mm | A surviving Casaba howitzer detonates three kilometres out, and a spear of nuclear plasma cuts Bastion in two. | none | Directed nuclear jet, break-up, venting | White noise, then silence | O3 | |
| 28 | 114–117 | 2737–2808 | Cooling | MS, 50 mm, slow drift | Debris drifts past the Endeavor. Its fins are still white-hot, one is missing, the CIWS barrels spin down and the lens glow fades. | ciws_rpm →0; laser_power →0; heat 3.2→2.6 | Floating debris | Ticking, a long exhale | D7 | img/lookyoke_final.jpg |
| 29 | 117–120 | 2809–2880 | Hold | EWS, 35 mm, locked off | The Endeavor, silhouetted against Harrow's night side with its radiators glowing. Cut to black. | heat 2.6 | City lights on the night side | Score resolves, then silence | none | img/hero_final.jpg |

## Tactical maps (captions)

- **A · Arrival (0:00–0:24).** The group exits warp outside the Shoals at about 180 km/s and flips to burn toward Harrow (O1). The jettisoned shields are left drifting on the old vector. The destroyers' network screen goes up (O2). Harrow's pods and platforms sit cold in the belt, marked on the map but not yet seen.
- **B · Long reach (0:24–0:52).** The hedgehog's volley arcs toward Kest and Bastion (O3). The belt wakes as pods cold-launch into the flank and railgun platforms fire on the braking line (HO1, HO2). A destroyer is lost. The Astrid answers with the spinal cannon against a platform that cannot dodge (O4).
- **C · The Shoals (0:52–1:34).** The line threads the belt with fins stowed (D3, D5). The drone screens clash (O7, HO4) and Kest's mass driver denies lanes (HO3). Harrow's lasers blind the sensors (HO5). Overheated, the Endeavor deploys its fins and is hit, then rolls a broadside and runs the lance (O6).
- **D · Hammer and anvil (1:34–2:00).** Destroyers and arrays blind Bastion (O5). The second hedgehog wave, with Casaba warheads, converges on a single arrival time (O3) and saturates Bastion's PD wall (HD5). Into that gap the Astrid's spinal slug lands, and a Casaba spear finishes the monitor (O4, O7).

## Doctrine rules (draft)

Each side's doctrine follows from what it has and where it stands. The LREF must cross open space to a defended world with the ships it brought, so it fights for tempo and picture. Harrow can wait, hide and fire from ground it surveyed long ago, so it fights for the moment the attacker becomes predictable.

### LREF: offensive

| ID | Rule | Detail |
|---|---|---|
| O1 | Arrive braked and together | Warp out beyond the debris line and stagger the exits over seconds, then flip and burn at once. Jettison the impact shields when the burn starts: they only protect during transit, and they block the forward arcs. |
| O2 | See first, speak last | The Astrid's AVPSA builds the picture passively. Destroyers raise the local network screen so the group goes radio-silent, and EW drones push that screen ahead of the line. |
| O3 | Saturate on a clock | Hedgehog frigates fire in waves timed to arrive together, with mixed payloads: kinetic, Casaba howitzer, decoy and EW. The first wave spends the enemy's PD, ammunition and heat. The second wave kills. |
| O4 | Guns on what can't dodge | Railguns and the spinal cannon engage fixed or committed targets: emplacements, stations, and ships locked in a burn. Against a ship that is free to manoeuvre, fire only inside about 1,000 km. |
| O5 | Blind before the blow | Laser arrays dazzle the target's optics and destroyers jam and spoof its fire control. Then the strike lands, while the target is deaf and half blind. |
| O6 | Close with purpose | Cruisers go to knife range only once the enemy's PD is saturated. Then they roll to bring every battery to bear, and use plasma lances inside 50 km. |
| O7 | Layer the arms | Drones, then corvettes, frigates, cruisers and finally the heavy cruiser. Each layer spends the enemy's attention for the next, and the spinal cannon fires into the gap. |

### LREF: defensive

| ID | Rule | Detail |
|---|---|---|
| D1 | Six layers against missiles | In order from the outside: EW spoofing and jamming, decoys, chaff, flare and smoke screens, main laser arrays at long range, PD lasers, then CIWS. |
| D2 | Spread out | Keep 50–200 km between ships, so that one nuke or one stream of slugs cannot take two. |
| D3 | Heat discipline | Keep radiators stowed on the threat axis and fight on heat sinks. Deploy fins only behind cover or when the heat forces it, and rotate firing duty between arrays. |
| D4 | Random walk | Jink on RCS whenever the ship is within an enemy railgun's time of flight. |
| D5 | Use the terrain | Asteroids and planetary shadow are cover from long-range fire and from sensors. |
| D6 | Screen the screen | Corvettes and PD drones kill fighters and drones before they reach the line. |
| D7 | Spend what is spendable | Radiators and drones are consumables. At action stations the hab rings spin down and the armoured modules are sealed. |

### Harrow: offensive

| ID | Rule | Detail |
|---|---|---|
| HO1 | Strike the braking fleet | A decelerating attacker's path is predictable for minutes. That is the window in which kinetic fire pays. |
| HO2 | Cold ambush | Missile pods and railgun platforms sit dark in the belt on heat sinks. They cold-launch and light their motors late. Each fires once and dies. |
| HO3 | Home-field geometry | The Kest mass driver has surveyed every lane through the belt. It fires to deny lanes and herd the attacker toward the mines and platforms. |
| HO4 | Swarm the screen | Fighters and drones launch from Kest's shadow to overload point defence and draw fire. |
| HO5 | Blind the eye | Planetary laser arrays dazzle sensors across the belt, while EW floods networks and spoofs tracks. |
| HO6 | Anvil and hammer | Bastion anchors in high orbit under the emplacements' umbrella, and the frigates hammer the attacker's flank. |

### Harrow: defensive

| ID | Rule | Detail |
|---|---|---|
| HD1 | Depth | In layers from the outside: belt pickets and mines, emplacements, the mobile squadron, Bastion, then the planetary batteries. The attacker bleeds at every layer. |
| HD2 | Decoys everywhere | Thermal and radar emitters mimic frigates, and the real ships hide among them. |
| HD3 | Hide in clutter | Use the belt, the moon's shadow and the planetary limb to stay hidden. |
| HD4 | Trade space for time | Fall back toward the planet's guns and make the attacker come through the kill zone. |
| HD5 | PD wall | Bastion's dense umbrella of PDCs and lasers guards the orbital lanes. It can be saturated but not slipped past. |
| HD6 | Spend the cheap things | Pods, mines and drones exist to drain the attacker's missiles, heat and time. |

## Weapons in employ (draft)

**LREF**
- **Kinetics:** twin railgun batteries, used on anything that cannot dodge. The Astrid's spinal cannon kills stations and monitors.
- **DEW:** laser focusing arrays for long point defence, burning at short range and dazzling sensors far out; PD lasers for the inner missile layer. The beams are invisible and only the lenses glow.
- **Plasma:** plasma lances, where the ship's own field bottles a plasma jet, for knife-range kills. Plasma torpedoes on frigates.
- **Nuclear:** Casaba-howitzer warheads on missiles, which throw a directed nuclear plasma spear from 1 to 5 km standoff.
- **Missiles:** delivery platforms carrying kinetic, nuclear, decoy and EW payloads. Hedgehog frigates provide saturation; the cruisers' VLS provides precision.
- **Defence:** 16 CIWS rotary cannons; chaff, flare and smoke launchers; EW jammers; the destroyers' network screen; decoy drones.

**Harrow**
- **Kinetics:** the Kest mass driver, firing huge slugs from an airless surface down surveyed lanes; stealthed railgun platforms in the belt; Bastion's heavy turrets; coilgun frigates.
- **DEW:** planetary laser arrays used for dazzle; PD lasers on Bastion.
- **Missiles:** cold-launch pods in the belt and frigate launchers.
- **Mines:** proximity nuclear mines seeded along the fast lanes through the Shoals.
- **Strike craft:** fighter and drone swarms launched from Kest's shadow.
- **Defence:** Bastion's PD wall of PDCs and lasers, thermal and radar decoys, jamming stations, and emplacements that hide in clutter.

## Mechanics the draft rests on (to be checked)

- **Heat is the real magazine.** Every laser shot, capacitor discharge and burn ends up as heat, and in vacuum the only way to lose heat is to radiate it. Radiators shed it fast, but deployed fins are huge, fragile and glow in infrared. With fins stowed, a ship fights on heat sinks for a few minutes. An overheating ship must stop firing or show its radiators (shots 18 and 19).
- **Time of flight decides kinetics.** A 20 km/s slug takes 50 s to cross 1,000 km, and a ship that keeps jinking will not be there when it arrives. Railguns therefore kill fixed targets, knife-range targets, and ships locked into a predictable burn.
- **Light is instant but spreads.** A laser spot's diameter is about 2.44 λ d / D. A 3.3 m UV array focuses to roughly a 0.26 m spot at 1,000 km, which is deadly, but 2.6 m at 10,000 km, which is merely hot. Far out, lasers blind optics rather than kill.
- **You cannot hide a burning drive.** Reactors, drives and radiators are visible in infrared across a system. Only cold, passive objects in clutter stay hidden, and only until they fire. The warp-exit flash tells Harrow the LREF has arrived; the ambush tells the LREF where the platforms are.

**Engagement envelopes (working numbers)**

| System | Effective range | Time to target | Best use | Beaten by |
|---|---|---|---|---|
| Laser focusing array (3.3 m UV) | ≤ 2,000 km kill · 50,000 km dazzle | instant | Long PD, blinding, burning armour | Smoke and chaff screens, ablative armour, rolling the target |
| PD laser (1.6 m) | ≤ 500 km | instant | Missiles and drones | Saturation, decoys |
| Twin railgun battery | ≤ 1,000 km vs ships | 5–60 s | Committed and knife-range targets | Random-walk jinking, range |
| Spinal cannon (Astrid) | ≥ 10,000 km vs fixed | tens of s | Stations, platforms, monitors | Moving and dispersing |
| Mass driver (Kest) | ~100,000 km surveyed lanes | minutes | Denying belt lanes, herding | Unpredictable routes, rock cover |
| Missile (multi-payload) | 10⁵–10⁶ km | minutes | Saturation, nuclear delivery | Layered PD, EW, decoys |
| Casaba howitzer | 1–5 km standoff | instant jet | Penetrating armour | Killing the carrier missile early |
| Plasma lance | ≤ 50 km | near-instant | Knife fights | Staying out of range |
| CIWS / PDC | ≤ 5 km | < 1 s | Last-ditch missile kill | Saturation, Casaba standoff |

## Production notes (draft)

**Assets.** ✓ = built when the draft was written. See `../01_PROJECT_CONTEXT.md` for the current state.
- ✓ L.R.E.F.S. Endeavor: full rig (twin railguns, well batteries, SAVAGES-style lasers, shield launch, radiators, RCS).
- ✓ Missile asset with plume and thrust property.
- ✓ Orbital environment: world-shader planet, sun, grade and compositor.
- ○ L.R.E.F.S. Astrid: Hanuman heavy cruiser with spinal cannon, 8 stacked fins and the AVPSA dish.
- ○ Frigates: hedgehog missile variant and gun variant.
- ○ Destroyer: EW ship with jamming drones.
- ○ Corvettes and LREF drones.
- ○ Harrow: monitor Bastion, coilgun frigates, picket corvettes, fighter and drone swarm.
- ○ Harrow emplacements: stealth missile pod, railgun platform, proximity mine, Kest mass driver, planetary laser array.
- ○ Environment: Harrow re-dress of the planet shader, moon Kest, the Shoals (instanced asteroid field).
- ○ FX: warp-exit flash, PDC tracers, chaff, flares and smoke screens, intercept and nuclear flashes, slug impacts, fin shatter, debris, plasma jet, dazzle bloom, EW glitch overlay.

**Close-up detail zones on the Endeavor.** Hero detail only has to exist where the camera goes.
- Front warp ring, shield mounts and release latches, bow RCS: shots 2, 5.
- Port chamfer lasers and PD lasers (lenses, MLI, yokes), port CIWS: shots 9, 15, 28.
- Sensor mast window: shot 17.
- Radiator slots, doors and fins, stern shoulders: shots 18, 19, 29.
- Port twin railgun turrets, dorsal well battery and lift: shot 20.
- Nose plasma lances and antenna boom: shot 22.

**Render plan (draft; the user now wants Cycles, so revisit).** Block and time the whole film in EEVEE as an animatic. Render hero close-ups in Cycles with OptiX at 128 samples, about 30–40 s per frame. Render wides and space shots in EEVEE. Keep the grade (halation, black crush, grain, vignette) shared by every shot.
